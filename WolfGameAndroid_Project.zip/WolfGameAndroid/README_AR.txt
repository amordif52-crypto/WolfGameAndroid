لعبة الذئب - مشروع Android

هذا مشروع Android Studio يغلّف لعبة الذئب داخل تطبيق Android يعمل دون إنترنت.

لبناء ملف APK:
1) ثبّت Android Studio على الكمبيوتر.
2) افتح مجلد WolfGameAndroid في Android Studio.
3) انتظر انتهاء Gradle Sync وثبّت Android SDK Platform 35 إذا طُلب منك.
4) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) ستجد ملف APK في app/build/outputs/apk/debug/app-debug.apk.

ملاحظة: هذا ملف مشروع قابل للبناء، وليس ملف APK مُجمّعًا. بيئة إنشاء الملف الحالية لا تحتوي على Android SDK/Gradle لتجميع APK مباشرة.
